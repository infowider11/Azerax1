<?php include_once 'include/header.php'; ?>


<div class="commn_dasboard p_120">
	<div class="container">
		<div class="row">
<div class="col-sm-12">
				<div class="right_box">
					<div class="heddding_1">

<?php echo $this->session->flashdata('msg'); ?>


					</div>
				</div>
</div>
</div>
</div>
</div>


<?php include_once 'include/footer.php'; ?>