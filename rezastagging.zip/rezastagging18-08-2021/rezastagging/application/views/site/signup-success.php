
<?php include ('include/header.php') ?>

<section class="login_box_area p_120">
	<div class="container">
		<div class="row">
		
			<?php echo $this->session->flashdata('msg'); ?> 
				
				
		</div>
	</div>
</section>
			

<?php include ('include/footer.php') ?>

