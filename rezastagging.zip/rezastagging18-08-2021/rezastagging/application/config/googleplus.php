<?php

defined('BASEPATH') OR exit('No direct script access allowed');

$config['googleplus']['application_name'] = 'crowdfunding';
$config['googleplus']['client_id']        = '492232137117-ll3p6bg78i68jtf5fspgj1g98hr5c5oo.apps.googleusercontent.com';
$config['googleplus']['client_secret']    = 'j3itF7FaHSvvVu8A0KOXuXue';
$config['googleplus']['redirect_uri']     = 'https://www.webwiders.com/WEB01/Buyer-Seller/google_login';
$config['googleplus']['api_key']          = '';
$config['googleplus']['scopes']           = array();

